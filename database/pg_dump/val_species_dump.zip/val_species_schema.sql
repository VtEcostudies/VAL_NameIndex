--
-- PostgreSQL database dump
--

-- Dumped from database version 10.3
-- Dumped by pg_dump version 13.0

-- Started on 2021-01-02 21:24:18

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'SQL_ASCII';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 609 (class 1247 OID 40096)
-- Name: val_location_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.val_location_type AS ENUM (
    'state',
    'county',
    'town',
    'village',
    'biophysical_region'
);


ALTER TYPE public.val_location_type OWNER TO postgres;

--
-- TOC entry 224 (class 1255 OID 66077)
-- Name: generate_new_val_taxon_id(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.generate_new_val_taxon_id() RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
	next_int integer;
	next_val text;
BEGIN
	--check to see if we're inserting a VAL custom taxon
	--IF (substr(NEW."taxonId",1,6) = 'VTSR:*') THEN

		SELECT max(new_val) AS new_max FROM (
			SELECT
				"taxonId",
				TO_NUMBER(substr("taxonId",5,10), '99999') AS new_val
			FROM val_species
			WHERE "taxonId" LIKE 'VTSR:%'
		) max_new
		INTO next_int;

		next_int := next_int + 1;
		next_val := concat('VTSR:', next_int::TEXT );

		--NEW."taxonId" := next_val;

	--END IF;

	--RETURN NEW;
	RETURN next_val;
END;
$$;


ALTER FUNCTION public.generate_new_val_taxon_id() OWNER TO postgres;

--
-- TOC entry 214 (class 1255 OID 66779)
-- Name: insert_val_vernacular(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.insert_val_vernacular() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
	exists record;
BEGIN

	SELECT "vernacularName", "scientificName", "taxonId"
	FROM val_vernacular
	WHERE LOWER("vernacularName") = LOWER(NEW."vernacularName") AND "taxonId" = NEW."taxonId"
	INTO exists;

	IF exists."vernacularName" IS NOT NULL THEN
		--IF exists."taxonId" = NEW."taxonId" THEN
			--RAISE EXCEPTION 'vernacularName % already exists.', NEW."vernacularName";
			RAISE SQLSTATE '23505';
		--END IF;
	END IF;
	
	RETURN NEW;
END;
$$;


ALTER FUNCTION public.insert_val_vernacular() OWNER TO postgres;

--
-- TOC entry 226 (class 1255 OID 40887)
-- Name: set_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
   NEW."updatedAt" = now(); 
   RETURN NEW;
END;
$$;


ALTER FUNCTION public.set_updated_at() OWNER TO postgres;

--
-- TOC entry 220 (class 1255 OID 66078)
-- Name: trigger_new_val_taxon_id(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trigger_new_val_taxon_id() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
	next_val text;
	taxon_exists text;
BEGIN
	--check to see if we're inserting a VAL custom taxon
	IF (substr(NEW."taxonId",1,6) = 'VTSR:*') THEN

		SELECT generate_new_val_taxon_id() INTO next_val;

		NEW."taxonId" := next_val;
		NEW."speciesId" := next_val;
		
		--if missing, assign acceptedNameUsage to the incoming scientificName
		IF (NEW."acceptedNameUsage" IS NULL) THEN
			NEW."acceptedNameUsage" := NEW."scientificName";
		END IF;
		
		--if missing, assign acceptedNameUsageId to the new taxonId
		IF (NEW."acceptedNameUsageId" IS NULL) THEN
			NEW."acceptedNameUsageId" := next_val;
		END IF;
		
		--if missing, assign taxonomicStatus to 'accepted'
		IF (NEW."taxonomicStatus" IS NULL) THEN
			NEW."taxonomicStatus" := 'accepted';
		END IF;
		
		SELECT "taxonId" FROM val_species WHERE "scientificName"=NEW."scientificName" INTO taxon_exists;
		
		IF taxon_exists IS NOT NULL THEN
			--RAISE EXCEPTION 'scientificName % already exists.', NEW."scientificName";
			RAISE SQLSTATE '23505';
		END IF;

	END IF;

	RETURN NEW;
END;
$$;


ALTER FUNCTION public.trigger_new_val_taxon_id() OWNER TO postgres;

--
-- TOC entry 216 (class 1255 OID 57738)
-- Name: vernacular_split_names(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.vernacular_split_names() RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
  i integer := 1;
BEGIN 
LOOP
    RAISE NOTICE 'Splitting %the comma-separated pieces...', i;
	insert into val_vernacular ("taxonId","scientificName","vernacularName","lifeStage","sex","language","countryCode","source")
	select 
		"taxonId", "scientificName",TRIM(split_part("vernacularName", ',', i)),"lifeStage","sex","language","countryCode","source"
	from val_vernacular 
	where 
		"vernacularName" like '%,%' 
		and split_part("vernacularName", ',', i) <> ''
		and split_part("vernacularName", ',', i) NOT like '%subspecies%'
		and split_part("vernacularName", ',', i) NOT like '% ssp %'
		and split_part("vernacularName", ',', i) NOT like '% ssp. %'
		and split_part("vernacularName", ',', i) NOT like '%variety%'
		and split_part("vernacularName", ',', i) NOT like '% var. %'
	ON CONFLICT("taxonId", "vernacularName") DO NOTHING;	
    i := i + 1;
	EXIT WHEN i > 4;
END LOOP;

RAISE NOTICE 'Splitting & pieces...';

INSERT INTO val_vernacular ("taxonId","scientificName","vernacularName","lifeStage","sex","language","countryCode","source")
	SELECT "taxonId","scientificName",TRIM(split_part("vernacularName", ' & ', 2)),"lifeStage","sex","language","countryCode","source"
	FROM val_vernacular 
	WHERE "vernacularName" LIKE '% & %' 
	AND split_part("vernacularName", ' & ', 2) != ''
ON CONFLICT("taxonId", "vernacularName") DO NOTHING;


RAISE NOTICE 'Splitting `and` pieces...';

INSERT INTO val_vernacular ("taxonId","scientificName","vernacularName","lifeStage","sex","language","countryCode","source")
	SELECT "taxonId","scientificName",TRIM(split_part("vernacularName", ' and ', 2)),"lifeStage","sex","language","countryCode","source"
	FROM val_vernacular 
	WHERE "vernacularName" LIKE '% and %' 
	AND split_part("vernacularName", ' and ', 2) != ''
ON CONFLICT("taxonId", "vernacularName") DO NOTHING;

RETURN 'DONE';
END; $$;


ALTER FUNCTION public.vernacular_split_names() OWNER TO postgres;

SET default_tablespace = '';

--
-- TOC entry 203 (class 1259 OID 41093)
-- Name: val_collection; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.val_collection (
    "collectionCode" character varying NOT NULL,
    "collectionName" character varying NOT NULL,
    "collectionDesc" character varying,
    "collectionUrl" character varying,
    "institutionCode" character varying,
    "createdAt" timestamp without time zone DEFAULT now(),
    "updatedAt" timestamp without time zone DEFAULT now()
);


ALTER TABLE public.val_collection OWNER TO postgres;

--
-- TOC entry 206 (class 1259 OID 41273)
-- Name: val_conservation_status; Type: TABLE; Schema: public; Owner: val
--

CREATE TABLE public.val_conservation_status (
    "taxonId" character varying NOT NULL,
    "scientificName" character varying NOT NULL,
    "SGCN" boolean,
    "stateRank" character varying[],
    "globalRank" character varying[],
    "federalList" character varying[],
    "stateList" character varying[],
    "createdAt" timestamp without time zone DEFAULT now(),
    "updatedAt" timestamp without time zone DEFAULT now()
);


ALTER TABLE public.val_conservation_status OWNER TO postgres;

--
-- TOC entry 197 (class 1259 OID 40146)
-- Name: val_distribution; Type: TABLE; Schema: public; Owner: val
--

CREATE TABLE public.val_distribution (
    "distributionId" integer NOT NULL,
    "taxonId" character varying NOT NULL,
    "stateRank" character varying,
    "federalListing" character varying,
    sgcn boolean,
    "locationType" public.val_location_type,
    "locationId" character varying,
    locality character varying,
    "countryCode" character varying,
    "lifeStage" character varying,
    "occurrenceStatus" character varying,
    "threatStatus" character varying,
    "establishmentMeans" character varying,
    "appendixCITES" character varying,
    "eventDate" date,
    "startDayOfYear" integer,
    "endDayOfYear" integer,
    source character varying,
    "occurrenceRemarks" character varying,
    "datasetId" character varying
);


ALTER TABLE public.val_distribution OWNER TO postgres;

--
-- TOC entry 196 (class 1259 OID 40144)
-- Name: val_distribution_distributionId_seq; Type: SEQUENCE; Schema: public; Owner: val
--

CREATE SEQUENCE public."val_distribution_distributionId_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."val_distribution_distributionId_seq" OWNER TO postgres;

--
-- TOC entry 2906 (class 0 OID 0)
-- Dependencies: 196
-- Name: val_distribution_distributionId_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: val
--

ALTER SEQUENCE public."val_distribution_distributionId_seq" OWNED BY public.val_distribution."distributionId";


--
-- TOC entry 201 (class 1259 OID 40780)
-- Name: val_gbif_taxon_id; Type: TABLE; Schema: public; Owner: val
--

CREATE TABLE public.val_gbif_taxon_id (
    "gbifId" integer NOT NULL
);


ALTER TABLE public.val_gbif_taxon_id OWNER TO postgres;

--
-- TOC entry 200 (class 1259 OID 40778)
-- Name: val_gbif_taxon_id_gbifId_seq; Type: SEQUENCE; Schema: public; Owner: val
--

CREATE SEQUENCE public."val_gbif_taxon_id_gbifId_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."val_gbif_taxon_id_gbifId_seq" OWNER TO postgres;

--
-- TOC entry 2907 (class 0 OID 0)
-- Dependencies: 200
-- Name: val_gbif_taxon_id_gbifId_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: val
--

ALTER SEQUENCE public."val_gbif_taxon_id_gbifId_seq" OWNED BY public.val_gbif_taxon_id."gbifId";


--
-- TOC entry 202 (class 1259 OID 41066)
-- Name: val_institution; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.val_institution (
    "institutionCode" character varying NOT NULL,
    "institutionName" character varying NOT NULL,
    "institutionDesc" character varying,
    "createdAt" timestamp without time zone DEFAULT now(),
    "updatedAt" timestamp without time zone DEFAULT now()
);


ALTER TABLE public.val_institution OWNER TO postgres;

--
-- TOC entry 199 (class 1259 OID 40737)
-- Name: val_reject; Type: TABLE; Schema: public; Owner: val
--

CREATE TABLE public.val_reject (
    "rejectReason" character varying NOT NULL,
    "gbifId" integer NOT NULL,
    "taxonId" character varying NOT NULL,
    "scientificName" character varying,
    "acceptedNameUsageId" character varying NOT NULL,
    "acceptedNameUsage" character varying NOT NULL,
    "parentNameUsageId" character varying NOT NULL,
    "taxonRank" character varying NOT NULL,
    "taxonomicStatus" character varying,
    "nomenclaturalCode" character varying,
    "scientificNameAuthorship" character varying,
    "specificEpithet" character varying,
    "infraspecificEpithet" character varying,
    "vernacularName" character varying,
    "taxonRemarks" character varying,
    "datasetName" character varying,
    "datasetId" character varying,
    kingdom character varying,
    "kingdomId" integer,
    phylum character varying,
    "phylumId" integer,
    class character varying,
    "classId" integer,
    "order" character varying,
    "orderId" integer,
    family character varying,
    "familyId" integer,
    genus character varying,
    "genusId" integer,
    species character varying,
    "speciesId" integer
);


ALTER TABLE public.val_reject OWNER TO postgres;

--
-- TOC entry 198 (class 1259 OID 40729)
-- Name: val_species; Type: TABLE; Schema: public; Owner: val
--

CREATE TABLE public.val_species (
    "gbifId" integer DEFAULT 0 NOT NULL,
    "taxonId" character varying NOT NULL,
    "scientificName" character varying NOT NULL,
    "acceptedNameUsageId" character varying NOT NULL,
    "acceptedNameUsage" character varying NOT NULL,
    "parentNameUsageId" character varying NOT NULL,
    "taxonRank" character varying NOT NULL,
    "taxonomicStatus" character varying,
    "nomenclaturalCode" character varying,
    "scientificNameAuthorship" character varying,
    "specificEpithet" character varying,
    "infraspecificEpithet" character varying,
    "vernacularName" character varying,
    "taxonRemarks" character varying,
    "datasetName" character varying,
    "datasetId" character varying,
    kingdom character varying,
    "kingdomId" text,
    phylum character varying,
    "phylumId" text,
    class character varying,
    "classId" text,
    "order" character varying,
    "orderId" text,
    family character varying,
    "familyId" text,
    genus character varying,
    "genusId" text,
    species character varying,
    "speciesId" text,
    "bibliographicCitation" character varying,
    "createdAt" timestamp without time zone DEFAULT now(),
    "updatedAt" timestamp without time zone DEFAULT now(),
    "references" character varying,
    "institutionCode" character varying,
    "collectionCode" character varying,
    "establishmentMeans" character varying
);


ALTER TABLE public.val_species OWNER TO postgres;

--
-- TOC entry 207 (class 1259 OID 65955)
-- Name: val_status_level; Type: TABLE; Schema: public; Owner: val
--

CREATE TABLE public.val_status_level (
    "statusLevelId" character varying NOT NULL,
    "statusLevelName" character varying NOT NULL,
    "statusLevelDesc" character varying
);


ALTER TABLE public.val_status_level OWNER TO postgres;

--
-- TOC entry 209 (class 1259 OID 65971)
-- Name: val_status_qualifier; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.val_status_qualifier (
    "statusQualifierId" character varying NOT NULL,
    "statusQualifierName" character varying NOT NULL,
    "statusQualifierDesc" character varying
);


ALTER TABLE public.val_status_qualifier OWNER TO postgres;

--
-- TOC entry 208 (class 1259 OID 65963)
-- Name: val_status_scope; Type: TABLE; Schema: public; Owner: val
--

CREATE TABLE public.val_status_scope (
    "statusScopeId" character varying NOT NULL,
    "statusScopeName" character varying NOT NULL,
    "statusScopeDesc" character varying
);


ALTER TABLE public.val_status_scope OWNER TO postgres;

--
-- TOC entry 205 (class 1259 OID 41114)
-- Name: val_vernacular; Type: TABLE; Schema: public; Owner: val
--

CREATE TABLE public.val_vernacular (
    "vernacularId" integer NOT NULL,
    "taxonId" character varying NOT NULL,
    "scientificName" character varying NOT NULL,
    "vernacularName" character varying NOT NULL,
    "lifeStage" character varying,
    sex character varying,
    language character varying,
    "countryCode" character varying,
    source character varying,
    "createdAt" timestamp without time zone DEFAULT now(),
    "updatedAt" timestamp without time zone DEFAULT now(),
    preferred boolean
);


ALTER TABLE public.val_vernacular OWNER TO postgres;

--
-- TOC entry 204 (class 1259 OID 41112)
-- Name: val_vernacular_vernacularId_seq; Type: SEQUENCE; Schema: public; Owner: val
--

CREATE SEQUENCE public."val_vernacular_vernacularId_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."val_vernacular_vernacularId_seq" OWNER TO postgres;

--
-- TOC entry 2908 (class 0 OID 0)
-- Dependencies: 204
-- Name: val_vernacular_vernacularId_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: val
--

ALTER SEQUENCE public."val_vernacular_vernacularId_seq" OWNED BY public.val_vernacular."vernacularId";


--
-- TOC entry 2732 (class 2604 OID 40149)
-- Name: val_distribution distributionId; Type: DEFAULT; Schema: public; Owner: val
--

ALTER TABLE ONLY public.val_distribution ALTER COLUMN "distributionId" SET DEFAULT nextval('public."val_distribution_distributionId_seq"'::regclass);


--
-- TOC entry 2736 (class 2604 OID 40783)
-- Name: val_gbif_taxon_id gbifId; Type: DEFAULT; Schema: public; Owner: val
--

ALTER TABLE ONLY public.val_gbif_taxon_id ALTER COLUMN "gbifId" SET DEFAULT nextval('public."val_gbif_taxon_id_gbifId_seq"'::regclass);


--
-- TOC entry 2741 (class 2604 OID 41117)
-- Name: val_vernacular vernacularId; Type: DEFAULT; Schema: public; Owner: val
--

ALTER TABLE ONLY public.val_vernacular ALTER COLUMN "vernacularId" SET DEFAULT nextval('public."val_vernacular_vernacularId_seq"'::regclass);


--
-- TOC entry 2763 (class 2606 OID 41282)
-- Name: val_conservation_status unique_conservation_status_taxonId; Type: CONSTRAINT; Schema: public; Owner: val
--

ALTER TABLE ONLY public.val_conservation_status
    ADD CONSTRAINT "unique_conservation_status_taxonId" UNIQUE ("taxonId");


--
-- TOC entry 2759 (class 2606 OID 41146)
-- Name: val_vernacular unique_taxonid_vernacularname; Type: CONSTRAINT; Schema: public; Owner: val
--

ALTER TABLE ONLY public.val_vernacular
    ADD CONSTRAINT unique_taxonid_vernacularname UNIQUE ("taxonId", "vernacularName");


--
-- TOC entry 2757 (class 2606 OID 41102)
-- Name: val_collection val_collection_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.val_collection
    ADD CONSTRAINT val_collection_pkey PRIMARY KEY ("collectionCode");


--
-- TOC entry 2747 (class 2606 OID 40154)
-- Name: val_distribution val_distribution_pkey; Type: CONSTRAINT; Schema: public; Owner: val
--

ALTER TABLE ONLY public.val_distribution
    ADD CONSTRAINT val_distribution_pkey PRIMARY KEY ("distributionId");


--
-- TOC entry 2753 (class 2606 OID 40785)
-- Name: val_gbif_taxon_id val_gbif_taxon_id_pkey; Type: CONSTRAINT; Schema: public; Owner: val
--

ALTER TABLE ONLY public.val_gbif_taxon_id
    ADD CONSTRAINT val_gbif_taxon_id_pkey PRIMARY KEY ("gbifId");


--
-- TOC entry 2755 (class 2606 OID 41075)
-- Name: val_institution val_institution_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.val_institution
    ADD CONSTRAINT val_institution_pkey PRIMARY KEY ("institutionCode");


--
-- TOC entry 2749 (class 2606 OID 41000)
-- Name: val_species val_species_pkey; Type: CONSTRAINT; Schema: public; Owner: val
--

ALTER TABLE ONLY public.val_species
    ADD CONSTRAINT val_species_pkey PRIMARY KEY ("taxonId");


--
-- TOC entry 2751 (class 2606 OID 40998)
-- Name: val_species val_species_taxonId_key; Type: CONSTRAINT; Schema: public; Owner: val
--

ALTER TABLE ONLY public.val_species
    ADD CONSTRAINT "val_species_taxonId_key" UNIQUE ("taxonId");


--
-- TOC entry 2765 (class 2606 OID 65962)
-- Name: val_status_level val_status_level_pkey; Type: CONSTRAINT; Schema: public; Owner: val
--

ALTER TABLE ONLY public.val_status_level
    ADD CONSTRAINT val_status_level_pkey PRIMARY KEY ("statusLevelId");


--
-- TOC entry 2769 (class 2606 OID 65978)
-- Name: val_status_qualifier val_status_qualifier_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.val_status_qualifier
    ADD CONSTRAINT val_status_qualifier_pkey PRIMARY KEY ("statusQualifierId");


--
-- TOC entry 2767 (class 2606 OID 65970)
-- Name: val_status_scope val_status_scope_pkey; Type: CONSTRAINT; Schema: public; Owner: val
--

ALTER TABLE ONLY public.val_status_scope
    ADD CONSTRAINT val_status_scope_pkey PRIMARY KEY ("statusScopeId");


--
-- TOC entry 2761 (class 2606 OID 41124)
-- Name: val_vernacular val_vernacular_pkey; Type: CONSTRAINT; Schema: public; Owner: val
--

ALTER TABLE ONLY public.val_vernacular
    ADD CONSTRAINT val_vernacular_pkey PRIMARY KEY ("vernacularId");


--
-- TOC entry 2773 (class 2620 OID 66079)
-- Name: val_species trigger_insert_new_taxon; Type: TRIGGER; Schema: public; Owner: val
--

CREATE TRIGGER trigger_insert_new_taxon BEFORE INSERT ON public.val_species FOR EACH ROW EXECUTE PROCEDURE public.trigger_new_val_taxon_id();


--
-- TOC entry 2778 (class 2620 OID 66780)
-- Name: val_vernacular trigger_insert_val_vernacular; Type: TRIGGER; Schema: public; Owner: val
--

CREATE TRIGGER trigger_insert_val_vernacular BEFORE INSERT ON public.val_vernacular FOR EACH ROW EXECUTE PROCEDURE public.insert_val_vernacular();


--
-- TOC entry 2776 (class 2620 OID 41108)
-- Name: val_collection trigger_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_updated_at BEFORE UPDATE ON public.val_collection FOR EACH ROW EXECUTE PROCEDURE public.set_updated_at();


--
-- TOC entry 2779 (class 2620 OID 41288)
-- Name: val_conservation_status trigger_updated_at; Type: TRIGGER; Schema: public; Owner: val
--

CREATE TRIGGER trigger_updated_at BEFORE UPDATE ON public.val_conservation_status FOR EACH ROW EXECUTE PROCEDURE public.set_updated_at();


--
-- TOC entry 2775 (class 2620 OID 41076)
-- Name: val_institution trigger_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_updated_at BEFORE UPDATE ON public.val_institution FOR EACH ROW EXECUTE PROCEDURE public.set_updated_at();


--
-- TOC entry 2774 (class 2620 OID 40888)
-- Name: val_species trigger_updated_at; Type: TRIGGER; Schema: public; Owner: val
--

CREATE TRIGGER trigger_updated_at BEFORE UPDATE ON public.val_species FOR EACH ROW EXECUTE PROCEDURE public.set_updated_at();


--
-- TOC entry 2777 (class 2620 OID 41132)
-- Name: val_vernacular trigger_updated_at; Type: TRIGGER; Schema: public; Owner: val
--

CREATE TRIGGER trigger_updated_at BEFORE UPDATE ON public.val_vernacular FOR EACH ROW EXECUTE PROCEDURE public.set_updated_at();


--
-- TOC entry 2770 (class 2606 OID 41103)
-- Name: val_collection fk_institution_code; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.val_collection
    ADD CONSTRAINT fk_institution_code FOREIGN KEY ("institutionCode") REFERENCES public.val_institution("institutionCode");


--
-- TOC entry 2771 (class 2606 OID 41127)
-- Name: val_vernacular fk_taxon_id; Type: FK CONSTRAINT; Schema: public; Owner: val
--

ALTER TABLE ONLY public.val_vernacular
    ADD CONSTRAINT fk_taxon_id FOREIGN KEY ("taxonId") REFERENCES public.val_species("taxonId");


--
-- TOC entry 2772 (class 2606 OID 41283)
-- Name: val_conservation_status fk_taxon_id; Type: FK CONSTRAINT; Schema: public; Owner: val
--

ALTER TABLE ONLY public.val_conservation_status
    ADD CONSTRAINT fk_taxon_id FOREIGN KEY ("taxonId") REFERENCES public.val_species("taxonId");


-- Completed on 2021-01-02 21:24:18

--
-- PostgreSQL database dump complete
--

